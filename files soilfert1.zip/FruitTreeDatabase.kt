package com.ayman.soilfert2026

data class FruitTree(
    val name: String,
    val phosphorusRanges: List<Double>, // P2O5 كغ/هـ حسب 7 مستويات PPM
    val nitrogenRanges: List<Double>,   // N كغ/هـ حسب 5 مستويات PPM
    val potassiumRanges: List<Double>   // K2O كغ/هـ حسب 8 مستويات PPM
)

/**
 * فئات عمر الشجرة قبل مرحلة "الإثمار الكامل".
 * ⚠️ ملاحظة أمانة علمية: هذه النسب تقدير عام تقريبي، مستوحى من نمط النمو
 * الجذري المعروف للأشجار المثمرة عمومًا (مراجع مثل Haifa Group للزيتون والحمضيات)،
 * وليست أرقامًا رسمية موثقة من GCSAR لكل نوع شجرة على حدة.
 * جدول GCSAR (المصدر الأساسي هنا) يغطي فقط مرحلة "الإثمار الكامل" (100%).
 */
enum class TreeAgeStage(val label: String, val factor: Double) {
    YOUNG("فتية (قبل الإثمار أو بداياته)", 0.30),
    INTERMEDIATE("متوسطة العمر (إثمار متزايد)", 0.65),
    MATURE("بالغة مثمرة (إثمار كامل)", 1.0)
}

object FruitTreeDatabase {

    val phosphorusLevels = listOf(
        "أقل من 3 PPM (منخفض جداً)",
        "3.1 - 6 PPM (منخفض)",
        "6.1 - 9 PPM (متوسط)",
        "9.1 - 12 PPM (جيد)",
        "12.1 - 15 PPM (مرتفع)",
        "15.1 - 18 PPM (مرتفع جداً)",
        "أكثر من 18 PPM (عالي جداً)"
    )

    val nitrogenLevels = listOf(
        "أقل من 5 PPM (منخفض جداً)",
        "5.1 - 9 PPM (منخفض)",
        "9.1 - 15 PPM (متوسط)",
        "15.1 - 19 PPM (جيد)",
        "أكثر من 20 PPM (مرتفع)"
    )

    val potassiumLevels = listOf(
        "أقل من 60 PPM (منخفض جداً)",
        "61 - 120 PPM (منخفض)",
        "121 - 180 PPM (متوسط)",
        "181 - 240 PPM (جيد)",
        "241 - 300 PPM (مرتفع)",
        "301 - 360 PPM (مرتفع جداً)",
        "361 - 420 PPM (عالي جداً)",
        "أكثر من 420 PPM (ممتاز)"
    )

    // جدول GCSAR الرسمي: معدلات التسميد بناءً على تحليل التربة للأشجار المثمرة المروية
    val trees = listOf(
        FruitTree(
            name = "حمضيات",
            phosphorusRanges = listOf(140.0, 120.0, 100.0, 75.0, 50.0, 30.0, 0.0),
            nitrogenRanges = listOf(450.0, 425.0, 400.0, 200.0, 200.0),
            potassiumRanges = listOf(250.0, 240.0, 220.0, 200.0, 150.0, 100.0, 50.0, 0.0)
        ),
        FruitTree(
            name = "زيتون + كرمة",
            phosphorusRanges = listOf(140.0, 120.0, 100.0, 75.0, 50.0, 30.0, 0.0),
            nitrogenRanges = listOf(250.0, 225.0, 200.0, 150.0, 100.0),
            potassiumRanges = listOf(160.0, 140.0, 120.0, 100.0, 80.0, 60.0, 40.0, 0.0)
        ),
        FruitTree(
            name = "لوزيات",
            phosphorusRanges = listOf(140.0, 120.0, 100.0, 75.0, 50.0, 30.0, 0.0),
            nitrogenRanges = listOf(180.0, 170.0, 150.0, 120.0, 80.0),
            potassiumRanges = listOf(160.0, 140.0, 120.0, 100.0, 80.0, 60.0, 40.0, 0.0)
        ),
        FruitTree(
            name = "تفاحيات",
            phosphorusRanges = listOf(145.0, 135.0, 120.0, 90.0, 60.0, 40.0, 0.0),
            nitrogenRanges = listOf(250.0, 225.0, 200.0, 150.0, 100.0),
            potassiumRanges = listOf(160.0, 150.0, 140.0, 120.0, 90.0, 60.0, 40.0, 0.0)
        ),
        FruitTree(
            name = "فستق حلبي",
            phosphorusRanges = listOf(230.0, 220.0, 200.0, 150.0, 100.0, 50.0, 0.0),
            nitrogenRanges = listOf(250.0, 225.0, 200.0, 150.0, 100.0),
            potassiumRanges = listOf(250.0, 240.0, 220.0, 200.0, 150.0, 100.0, 50.0, 0.0)
        ),
        FruitTree(
            name = "رمان",
            phosphorusRanges = listOf(145.0, 135.0, 120.0, 90.0, 60.0, 40.0, 0.0),
            nitrogenRanges = listOf(250.0, 225.0, 200.0, 150.0, 100.0),
            potassiumRanges = listOf(160.0, 150.0, 140.0, 120.0, 90.0, 60.0, 40.0, 0.0)
        ),
        FruitTree(
            name = "تين + كاكي",
            phosphorusRanges = listOf(140.0, 120.0, 100.0, 90.0, 60.0, 40.0, 0.0),
            nitrogenRanges = listOf(180.0, 170.0, 150.0, 120.0, 80.0),
            potassiumRanges = listOf(160.0, 140.0, 120.0, 100.0, 80.0, 60.0, 40.0, 0.0)
        )
    ).sortedBy { it.name }

    // ⚠️ حدود PPM مختلفة عن CropDatabase - لا تُستخدم دوال المحاصيل هنا
    fun getPhosphorusIndex(ppm: Double): Int {
        return when {
            ppm < 3 -> 0
            ppm <= 6 -> 1
            ppm <= 9 -> 2
            ppm <= 12 -> 3
            ppm <= 15 -> 4
            ppm <= 18 -> 5
            else -> 6
        }
    }

    fun getNitrogenIndex(ppm: Double): Int {
        return when {
            ppm < 5 -> 0
            ppm <= 9 -> 1
            ppm <= 15 -> 2
            ppm <= 19 -> 3
            else -> 4
        }
    }

    fun getPotassiumIndex(ppm: Double): Int {
        return when {
            ppm < 60 -> 0
            ppm <= 120 -> 1
            ppm <= 180 -> 2
            ppm <= 240 -> 3
            ppm <= 300 -> 4
            ppm <= 360 -> 5
            ppm <= 420 -> 6
            else -> 7
        }
    }

    fun getTreeByName(name: String): FruitTree? = trees.find { it.name == name }
    fun getAllTreeNames(): List<String> = trees.map { it.name }
}
