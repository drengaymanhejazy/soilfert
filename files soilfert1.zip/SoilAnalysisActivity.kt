package com.ayman.soilfert2026

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

// ✅ إضافة: ثوابت نسب العناصر في الأسمدة التجارية الشائعة محليًا
// بدل الأرقام المباشرة (magic numbers) داخل الكود
object FertilizerConstants {
    const val UREA_N_PERCENT = 0.46                    // يوريا 46% N
    const val SUPERPHOSPHATE_P2O5_PERCENT = 0.18       // ✅ تصحيح: سوبر فوسفات عادي/ترابي 18% P2O5 (كان خطأً 46%)
    const val POTASSIUM_SULFATE_K2O_PERCENT = 0.50     // سلفات بوتاسيوم 50% K2O
}

class SoilAnalysisActivity : AppCompatActivity() {

    // تعريف عناصر الواجهة
    private lateinit var rgCategory: RadioGroup
    private lateinit var sectionCropPicker: LinearLayout
    private lateinit var sectionTreePicker: LinearLayout
    private lateinit var spinnerCrop: Spinner
    private lateinit var spinnerTree: Spinner
    private lateinit var rgIrrigation: RadioGroup
    private lateinit var rgAgeStage: RadioGroup
    private lateinit var inputTreeDensity: EditText
    private lateinit var rgUnit: RadioGroup
    private lateinit var inputN: EditText
    private lateinit var inputP: EditText
    private lateinit var inputK: EditText
    private lateinit var inputOM: EditText
    private lateinit var btnAnalyze: Button
    private lateinit var btnClear: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_soil_analysis)

        initViews()
        setupSpinners()
        setupButtons()
    }

    private fun initViews() {
        rgCategory = findViewById(R.id.rgCategory)
        sectionCropPicker = findViewById(R.id.sectionCropPicker)
        sectionTreePicker = findViewById(R.id.sectionTreePicker)
        spinnerCrop = findViewById(R.id.spinnerCrop)
        spinnerTree = findViewById(R.id.spinnerTree)
        rgIrrigation = findViewById(R.id.rgIrrigation)
        rgAgeStage = findViewById(R.id.rgAgeStage)
        inputTreeDensity = findViewById(R.id.inputTreeDensity)
        rgUnit = findViewById(R.id.rgUnit)
        inputN = findViewById(R.id.inputN)
        inputP = findViewById(R.id.inputP)
        inputK = findViewById(R.id.inputK)
        inputOM = findViewById(R.id.inputOM)
        btnAnalyze = findViewById(R.id.btnAnalyze)
        btnClear = findViewById(R.id.btnClear)

        // ✅ إضافة: التبديل بين قسم المحصول وقسم الشجرة حسب اختيار المستخدم
        rgCategory.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbCategoryTree) {
                sectionCropPicker.visibility = android.view.View.GONE
                sectionTreePicker.visibility = android.view.View.VISIBLE
            } else {
                sectionCropPicker.visibility = android.view.View.VISIBLE
                sectionTreePicker.visibility = android.view.View.GONE
            }
        }
    }

    private fun setupSpinners() {
        // الحصول على جميع المحاصيل من قاعدة البيانات
        val allCrops = CropDatabase.getAllCropNames()

        spinnerCrop.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            allCrops
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // ✅ إضافة: تعبئة قائمة الأشجار المثمرة
        val allTrees = FruitTreeDatabase.getAllTreeNames()
        spinnerTree.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            allTrees
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // التحقق من وجود المحصول في قاعدة البيانات
        spinnerCrop.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                val name = parent.getItemAtPosition(position).toString()
                val crop = CropDatabase.getCropByName(name)

                if (crop == null) {
                    Toast.makeText(this@SoilAnalysisActivity,
                        "⚠️ المحصول غير موجود في قاعدة البيانات",
                        Toast.LENGTH_SHORT).show()
                } else {
                    Log.d("Crop", "✔ ${crop.name}")
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun setupButtons() {
        btnAnalyze.setOnClickListener {
            if (!validateInputs()) return@setOnClickListener
            val result = buildResult()
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("RESULT_TEXT", result)
            startActivity(intent)
        }

        btnClear.setOnClickListener {
            clearInputs()
        }
    }

    private fun buildResult(): String {
        return if (rgCategory.checkedRadioButtonId == R.id.rbCategoryTree) {
            buildTreeResult()
        } else {
            buildCropResult()
        }
    }

    private fun buildCropResult(): String {
        // قراءة قيم تحليل التربة (PPM)
        val n = inputN.text.toString().toDoubleOrNull() ?: 0.0
        val p = inputP.text.toString().toDoubleOrNull() ?: 0.0
        val k = inputK.text.toString().toDoubleOrNull() ?: 0.0
        val om = inputOM.text.toString().toDoubleOrNull() ?: 0.0

        // تشخيص المستويات حسب معايير Excel
        val nStatus = diagnoseN(n)
        val pStatus = diagnoseP(p)
        val kStatus = diagnoseK(k)
        val omStatus = diagnoseOM(om)

        val cropName = spinnerCrop.selectedItem.toString()
        val crop = CropDatabase.getCropByName(cropName)

        // تحديد وحدة القياس المختارة (الجداول المرجعية بالأصل كغ/هكتار)
        val isHectare = rgUnit.checkedRadioButtonId == R.id.rbHectare
        val unitDivisor = if (isHectare) 1.0 else 10.0
        val unitLabel = if (isHectare) "كغ / هكتار" else "كغ / دونم"

        val result = StringBuilder()

        // ==============================
        // 🔹 قسم التشخيص
        // ==============================
        result.append("###DIAGNOSIS###\n")
        result.append("N : ${colorStatus(nStatus)}\n")
        result.append("P : ${colorStatus(pStatus)}\n")
        result.append("K : ${colorStatus(kStatus)}\n")
        result.append("OM : ${colorStatus(omStatus)}\n")

        // ==============================
        // 🔹 قسم التوصية السمادية النهائية
        // ==============================
        if (crop != null) {
            val nIndex = CropDatabase.getNitrogenIndex(n)
            val pIndex = CropDatabase.getPhosphorusIndex(p)
            val kIndex = CropDatabase.getPotassiumIndex(k)

            val targetN_KgPerHa = crop.nitrogenRanges.getOrElse(nIndex) { 0.0 }
            val targetP_KgPerHa = crop.phosphorusRanges.getOrElse(pIndex) { 0.0 }
            val targetK_KgPerHa = crop.potassiumRanges.getOrElse(kIndex) { 0.0 }

            // أثر المادة العضوية يُحتسب داخليًا على النيتروجين فقط قبل عرض الرقم النهائي
            val omFactor = getOrganicFactor(om)
            val finalN = (targetN_KgPerHa * omFactor) / unitDivisor
            val finalP = targetP_KgPerHa / unitDivisor
            val finalK = targetK_KgPerHa / unitDivisor

            val fert = calculateFertilizer(finalN, finalP, finalK)

            result.append("\n###NEEDS###\n")
            result.append("المحصول: $cropName\n\n")
            result.append("التوصية السمادية ($unitLabel):\n")
            result.append("  • نيتروجين (N):     ${String.format(Locale.US, "%.1f", finalN)} $unitLabel\n")
            result.append("  • فوسفور (P₂O₅):    ${String.format(Locale.US, "%.1f", finalP)} $unitLabel\n")
            result.append("  • بوتاسيوم (K₂O):   ${String.format(Locale.US, "%.1f", finalK)} $unitLabel\n")

            // ==============================
            // 🔹 قسم الأسمدة التجارية
            // ==============================
            result.append("\n###FERTILIZERS###\n")
            result.append("الأسمدة التجارية الموصى بها ($unitLabel):\n")
            result.append("  • يوريا (46% N):              ${String.format(Locale.US, "%.1f", fert.urea)} $unitLabel\n")
            result.append("  • سوبر فوسفات (18% P₂O₅):     ${String.format(Locale.US, "%.1f", fert.superPhosphate)} $unitLabel\n")
            result.append("  • سلفات بوتاسيوم (50% K₂O):   ${String.format(Locale.US, "%.1f", fert.potassiumSulfate)} $unitLabel\n")
        }

        // ==============================
        // 🔹 قسم التوصيات والإرشادات
        // ==============================
        result.append("\n\n###ADVICE###\n")
        result.append(soilAdvice(nStatus, pStatus, kStatus, omStatus).trim())

        // إضافة معلومات عن مستويات العناصر حسب Excel
        result.append("\n\n📊 **مستويات العناصر حسب التحليل:**\n")
        result.append("• النيتروجين: ${CropDatabase.nitrogenLevels.getOrElse(CropDatabase.getNitrogenIndex(n)) { "غير محدد" }}\n")
        result.append("• الفوسفور: ${CropDatabase.phosphorusLevels.getOrElse(CropDatabase.getPhosphorusIndex(p)) { "غير محدد" }}\n")
        result.append("• البوتاسيوم: ${CropDatabase.potassiumLevels.getOrElse(CropDatabase.getPotassiumIndex(k)) { "غير محدد" }}\n")
        result.append("• المادة العضوية: ${CropDatabase.organicMatterLevels.getOrElse(CropDatabase.getOrganicMatterIndex(om)) { "غير محدد" }}\n")

        return result.toString()
    }

    // ✅ إضافة: بناء تقرير التوصية للأشجار المثمرة (جدول GCSAR + تعديل الري والعمر)
    private fun buildTreeResult(): String {
        val n = inputN.text.toString().toDoubleOrNull() ?: 0.0
        val p = inputP.text.toString().toDoubleOrNull() ?: 0.0
        val k = inputK.text.toString().toDoubleOrNull() ?: 0.0
        val om = inputOM.text.toString().toDoubleOrNull() ?: 0.0

        val nStatus = diagnoseN(n)
        val pStatus = diagnoseTreeP(p)
        val kStatus = diagnoseTreeK(k)
        val omStatus = diagnoseOM(om)

        val treeName = spinnerTree.selectedItem.toString()
        val tree = FruitTreeDatabase.getTreeByName(treeName)

        val isHectare = rgUnit.checkedRadioButtonId == R.id.rbHectare
        val unitDivisor = if (isHectare) 1.0 else 10.0
        val unitLabel = if (isHectare) "كغ / هكتار" else "كغ / دونم"

        val isIrrigated = rgIrrigation.checkedRadioButtonId == R.id.rbIrrigated
        val irrigationFactor = if (isIrrigated) 1.0 else 0.5 // البعل = نصف الكمية حسب جدول GCSAR
        val irrigationLabel = if (isIrrigated) "مروي" else "بعل"

        val ageStage = when (rgAgeStage.checkedRadioButtonId) {
            R.id.rbAgeYoung -> TreeAgeStage.YOUNG
            R.id.rbAgeIntermediate -> TreeAgeStage.INTERMEDIATE
            else -> TreeAgeStage.MATURE
        }

        val density = inputTreeDensity.text.toString().toDoubleOrNull()

        val result = StringBuilder()

        result.append("###DIAGNOSIS###\n")
        result.append("N : ${colorStatus(nStatus)}\n")
        result.append("P : ${colorStatus(pStatus)}\n")
        result.append("K : ${colorStatus(kStatus)}\n")
        result.append("OM : ${colorStatus(omStatus)}\n")

        if (tree != null) {
            val nIndex = FruitTreeDatabase.getNitrogenIndex(n)
            val pIndex = FruitTreeDatabase.getPhosphorusIndex(p)
            val kIndex = FruitTreeDatabase.getPotassiumIndex(k)

            val baseN = tree.nitrogenRanges.getOrElse(nIndex) { 0.0 }
            val baseP = tree.phosphorusRanges.getOrElse(pIndex) { 0.0 }
            val baseK = tree.potassiumRanges.getOrElse(kIndex) { 0.0 }

            val finalN = (baseN * irrigationFactor * ageStage.factor) / unitDivisor
            val finalP = (baseP * irrigationFactor * ageStage.factor) / unitDivisor
            val finalK = (baseK * irrigationFactor * ageStage.factor) / unitDivisor

            val fert = calculateFertilizer(finalN, finalP, finalK)

            result.append("\n###NEEDS###\n")
            result.append("الشجرة: $treeName ($irrigationLabel)\n")
            result.append("الفئة العمرية: ${ageStage.label}\n\n")
            result.append("التوصية السمادية ($unitLabel):\n")
            result.append("  • نيتروجين (N):     ${String.format(Locale.US, "%.1f", finalN)} $unitLabel\n")
            result.append("  • فوسفور (P₂O₅):    ${String.format(Locale.US, "%.1f", finalP)} $unitLabel\n")
            result.append("  • بوتاسيوم (K₂O):   ${String.format(Locale.US, "%.1f", finalK)} $unitLabel\n")

            if (density != null && density > 0) {
                result.append("\nما يعادلها لكل شجرة واحدة:\n")
                result.append("  • نيتروجين (N):     ${String.format(Locale.US, "%.1f", finalN / density * 1000)} غ/شجرة\n")
                result.append("  • فوسفور (P₂O₅):    ${String.format(Locale.US, "%.1f", finalP / density * 1000)} غ/شجرة\n")
                result.append("  • بوتاسيوم (K₂O):   ${String.format(Locale.US, "%.1f", finalK / density * 1000)} غ/شجرة\n")
            }

            result.append("\n###FERTILIZERS###\n")
            result.append("الأسمدة التجارية الموصى بها ($unitLabel):\n")
            result.append("  • يوريا (46% N):              ${String.format(Locale.US, "%.1f", fert.urea)} $unitLabel\n")
            result.append("  • سوبر فوسفات (18% P₂O₅):     ${String.format(Locale.US, "%.1f", fert.superPhosphate)} $unitLabel\n")
            result.append("  • سلفات بوتاسيوم (50% K₂O):   ${String.format(Locale.US, "%.1f", fert.potassiumSulfate)} $unitLabel\n")

            if (density != null && density > 0) {
                result.append("\nما يعادلها لكل شجرة واحدة:\n")
                result.append("  • يوريا:              ${String.format(Locale.US, "%.1f", fert.urea / density * 1000)} غ/شجرة\n")
                result.append("  • سوبر فوسفات:        ${String.format(Locale.US, "%.1f", fert.superPhosphate / density * 1000)} غ/شجرة\n")
                result.append("  • سلفات بوتاسيوم:     ${String.format(Locale.US, "%.1f", fert.potassiumSulfate / density * 1000)} غ/شجرة\n")
            }
        }

        result.append("\n\n###ADVICE###\n")
        result.append(soilAdvice(nStatus, pStatus, kStatus, omStatus).trim())

        if (ageStage != TreeAgeStage.MATURE) {
            result.append("\n\n⚠️ ملاحظة: الكمية معدَّلة تقريبيًا حسب مرحلة عمر الشجرة، ويُفضّل الاعتماد على تحليل الأوراق للحصول على دقة أعلى في الأشجار غير المكتملة النمو.")
        }

        result.append("\n\n📊 **مستويات العناصر حسب التحليل:**\n")
        result.append("• النيتروجين: ${FruitTreeDatabase.nitrogenLevels.getOrElse(FruitTreeDatabase.getNitrogenIndex(n)) { "غير محدد" }}\n")
        result.append("• الفوسفور: ${FruitTreeDatabase.phosphorusLevels.getOrElse(FruitTreeDatabase.getPhosphorusIndex(p)) { "غير محدد" }}\n")
        result.append("• البوتاسيوم: ${FruitTreeDatabase.potassiumLevels.getOrElse(FruitTreeDatabase.getPotassiumIndex(k)) { "غير محدد" }}\n")
        result.append("• المادة العضوية: ${CropDatabase.organicMatterLevels.getOrElse(CropDatabase.getOrganicMatterIndex(om)) { "غير محدد" }}\n")

        return result.toString()
    }


    private fun diagnoseN(v: Double): String {
        return when (CropDatabase.getNitrogenIndex(v)) {
            0 -> "منخفض جداً"
            1 -> "منخفض"
            2 -> "متوسط"
            3 -> "جيد"
            else -> "مرتفع"
        }
    }

    private fun diagnoseP(v: Double): String {
        return when (CropDatabase.getPhosphorusIndex(v)) {
            0 -> "منخفض جداً"
            1 -> "منخفض"
            2 -> "متوسط"
            3 -> "جيد"
            4 -> "مرتفع"
            else -> "مرتفع جداً"
        }
    }

    // ✅ إضافة: تشخيص الفوسفور للأشجار (7 مستويات حسب جدول GCSAR للأشجار)
    private fun diagnoseTreeP(v: Double): String {
        return when (FruitTreeDatabase.getPhosphorusIndex(v)) {
            0 -> "منخفض جداً"
            1 -> "منخفض"
            2 -> "متوسط"
            3 -> "جيد"
            4 -> "مرتفع"
            5 -> "مرتفع جداً"
            else -> "عالي جداً"
        }
    }

    // ✅ إضافة: تشخيص البوتاسيوم للأشجار (8 مستويات حسب جدول GCSAR للأشجار)
    private fun diagnoseTreeK(v: Double): String {
        return when (FruitTreeDatabase.getPotassiumIndex(v)) {
            0 -> "منخفض جداً"
            1 -> "منخفض"
            2 -> "متوسط"
            3 -> "جيد"
            4 -> "مرتفع"
            5 -> "مرتفع جداً"
            6 -> "عالي جداً"
            else -> "ممتاز"
        }
    }

    private fun diagnoseK(v: Double): String {
        return when (CropDatabase.getPotassiumIndex(v)) {
            0 -> "منخفض جداً"
            1 -> "منخفض"
            2 -> "متوسط"
            3 -> "جيد"
            4 -> "مرتفع"
            5 -> "مرتفع جداً"
            6 -> "عالي جداً"
            else -> "ممتاز"
        }
    }

    private fun diagnoseOM(v: Double): String {
        val adjustedOm = if (v > 3.0) 3.0 else v
        return when (CropDatabase.getOrganicMatterIndex(adjustedOm)) {
            0 -> "منخفض"
            1 -> "متوسط"
            2 -> "مرتفع"
            else -> "عالية جداً"
        }
    }

    private fun getOrganicFactor(om: Double): Double {
        val adjustedOm = if (om > 3.0) 3.0 else om
        return when (CropDatabase.getOrganicMatterIndex(adjustedOm)) {
            0 -> 1.2  // أقل من 1% -> تحتاج سماد أكثر
            1 -> 1.0  // 1-2% -> معامل عادي
            2 -> 0.9  // 2-3% -> تقليل السماد قليلاً
            else -> 0.7 // أكثر من 3% -> تقليل السماد كثيراً
        }
    }

    // ✅ تصحيح: استخدام الثوابت الصحيحة بدل الأرقام المباشرة
    // النسبة الصحيحة للسوبر فوسفات العادي/الترابي هي 18% (كانت خطأً 46%)
    private fun calculateFertilizer(n: Double, p: Double, k: Double): FertilizerResult {
        val urea = if (n > 0) n / FertilizerConstants.UREA_N_PERCENT else 0.0
        val superPhosphate = if (p > 0) p / FertilizerConstants.SUPERPHOSPHATE_P2O5_PERCENT else 0.0
        val potassiumSulfate = if (k > 0) k / FertilizerConstants.POTASSIUM_SULFATE_K2O_PERCENT else 0.0
        return FertilizerResult(urea, superPhosphate, potassiumSulfate)
    }

    private fun colorStatus(s: String): String {
        return when {
            s.contains("منخفض") -> "🔴 $s"
            s.contains("متوسط") -> "🟠 $s"
            s.contains("جيد") -> "🟢 $s"
            s.contains("مرتفع") -> "🟢 $s"
            // ✅ تصحيح: "عالي" (بدون تاء) تغطي "عالي جداً"، و"ممتاز" لم تكن مغطاة إطلاقاً
            s.contains("عالي") -> "🟢 $s"
            s.contains("ممتاز") -> "🟢 $s"
            else -> "⚪ $s"
        }
    }

    private fun validateInputs(): Boolean {
        // ✅ إضافة حقل المادة العضوية (OM) الذي كان مفقودًا من التحقق
        // (سابقًا: لو تُرك فارغًا، كان يتحول تلقائيًا لـ 0.0 بصمت، فيُعطي توصية غير صحيحة
        // بزيادة التسميد 20% دون أن يعرف المستخدم أن السبب هو حقل فارغ)
        val inputs = listOf(
            inputN to "الآزوت",
            inputP to "الفوسفور",
            inputK to "البوتاسيوم",
            inputOM to "المادة العضوية"
        )

        for ((field, name) in inputs) {
            val value = field.text.toString().toDoubleOrNull()
            if (value == null || value < 0) {
                field.error = "قيمة غير صحيحة"
                Toast.makeText(this, "❌ تحقق من $name", Toast.LENGTH_SHORT).show()
                return false
            }
        }

        // ✅ إضافة: التحقق من حقل عدد الأشجار فقط إذا أدخل المستخدم قيمة فيه (حقل اختياري)
        val densityText = inputTreeDensity.text.toString()
        if (densityText.isNotBlank()) {
            val density = densityText.toDoubleOrNull()
            if (density == null || density <= 0) {
                inputTreeDensity.error = "قيمة غير صحيحة"
                Toast.makeText(this, "❌ تحقق من عدد الأشجار", Toast.LENGTH_SHORT).show()
                return false
            }
        }

        return true
    }

    private fun clearInputs() {
        inputN.text.clear()
        inputP.text.clear()
        inputK.text.clear()
        inputOM.text.clear()
        spinnerCrop.setSelection(0)
        spinnerTree.setSelection(0)
        rgUnit.check(R.id.rbDunum) // إعادة الوحدة الافتراضية إلى "دونم"
        rgCategory.check(R.id.rbCategoryCrop) // إعادة نوع الزراعة الافتراضي إلى "محصول حقلي"
        rgIrrigation.check(R.id.rbIrrigated)
        rgAgeStage.check(R.id.rbAgeMature)
        inputTreeDensity.text.clear()
        Toast.makeText(this, "✅ تم مسح الحقول", Toast.LENGTH_SHORT).show()
    }

    private fun soilAdvice(n: String, p: String, k: String, om: String): String {
        val advice = StringBuilder()
        advice.append("📦 **التوصيات والإرشادات:**\n\n")

        when {
            n.contains("منخفض") -> advice.append("• ⚠️ النيتروجين منخفض: يفضل إضافة السماد النيتروجيني على دفعات (قبل الزراعة، بعد 30 يوم، قبل التزهير)\n")
            n.contains("جيد") -> advice.append("• ✅ النيتروجين جيد: يمكن الاعتماد على برنامج تسميد اعتيادي\n")
            n.contains("مرتفع") -> advice.append("• 🟢 النيتروجين مرتفع: يفضل تقليل التسميد النيتروجيني لتجنب الاستطالة الزائدة\n")
        }

        when {
            p.contains("منخفض") -> advice.append("• ⚠️ الفوسفور منخفض: يضاف كاملاً قبل الزراعة لتحسين نمو الجذور\n")
            p.contains("جيد") -> advice.append("• ✅ الفوسفور جيد: يمكن الاكتفاء بالتسميد الأساسي\n")
            p.contains("مرتفع") -> advice.append("• 🟢 الفوسفور مرتفع: تجنب إضافة الفوسفور في الموسم الحالي\n")
        }

        when {
            k.contains("منخفض") -> advice.append("• ⚠️ البوتاسيوم منخفض: يضاف 50% قبل الزراعة و 50% بعد 45 يوم لتحسين جودة المحصول\n")
            k.contains("جيد") -> advice.append("• ✅ البوتاسيوم جيد: برنامج تسميد اعتيادي\n")
            k.contains("مرتفع") -> advice.append("• 🟢 البوتاسيوم مرتفع: تقليل الإضافة إلى الحد الأدنى\n")
        }

        when {
            om.contains("منخفض") -> advice.append("• 🌱 المادة العضوية منخفضة: ضرورة إضافة 15-20 طن/هكتار من السماد العضوي المتخمر\n")
            om.contains("متوسط") -> advice.append("• 🌿 المادة العضوية متوسطة: إضافة 10-15 طن/هكتار من السماد العضوي\n")
            om.contains("مرتفع") -> advice.append("• 🍂 المادة العضوية مرتفعة: إضافة 5-10 طن/هكتار للمحافظة على الخصوبة\n")
            om.contains("عالية") -> advice.append("• 🍃 المادة العضوية عالية جداً: إضافة 2-3 طن/هكتار فقط للمحافظة\n")
        }

        advice.append("\n💡 **نصائح عامة:**\n")
        advice.append("• إجراء تحليل للتربة كل 2-3 مواسم\n")
        advice.append("• الري المنتظم يزيد من كفاءة الأسمدة\n")
        advice.append("• تجنب التسميد في الأيام الحارة جداً\n")

        return advice.toString()
    }
}

data class FertilizerResult(
    val urea: Double,
    val superPhosphate: Double,
    val potassiumSulfate: Double
)
