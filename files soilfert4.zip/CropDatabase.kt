package com.ayman.soilfert2026

data class Crop(
    val name: String,
    val phosphorusRanges: List<Double>, // P2O5 كغ/هـ حسب 6 مستويات PPM
    val nitrogenRanges: List<Double>,   // N كغ/هـ حسب 5 مستويات PPM
    val potassiumRanges: List<Double>   // K2O كغ/هـ حسب 8 مستويات PPM
)

object CropDatabase {

    // ملاحظة: تم حذف القوائم phosphorusPPM / nitrogenPPM / potassiumPPM من هنا
    // لأنها كانت كودًا ميتًا (dead code) غير مستخدم في أي مكان بالمشروع،
    // والمنطق الفعلي لتحديد الفئة موجود في الدوال getPhosphorusIndex/getNitrogenIndex/getPotassiumIndex أدناه.
    // كما أن قائمة nitrogenPPM كانت تحتوي 7 حدود (6 فئات) بينما الدالة الفعلية تستخدم 5 فئات فقط - تناقض تم إزالته.

    // أسماء مستويات العناصر للتقرير
    val phosphorusLevels = listOf(
        "أقل من 3 PPM (منخفض جداً)",
        "3.1 - 5 PPM (منخفض)",
        "5.1 - 7 PPM (متوسط)",
        "7.1 - 9 PPM (جيد)",
        "9.1 - 12 PPM (مرتفع)",
        "أكثر من 12 PPM (مرتفع جداً)"
    )

    val nitrogenLevels = listOf(
        "أقل من 5 PPM (منخفض جداً)",
        "5.1 - 9 PPM (منخفض)",
        "9.1 - 15 PPM (متوسط)",
        "15.1 - 19 PPM (جيد)",
        "أكثر من 20 PPM (مرتفع)"
    )

    val potassiumLevels = listOf(
        "أقل من 60 PPM (منخفض جداً)",
        "61 - 120 PPM (منخفض)",
        "121 - 160 PPM (متوسط)",
        "161 - 240 PPM (جيد)",
        "241 - 250 PPM (مرتفع)",
        "251 - 260 PPM (مرتفع جداً)",
        "261 - 420 PPM (عالي جداً)",
        "أكثر من 420 PPM (ممتاز)"
    )

    // ملاحظة: تم حذف organicMatterBoundaries لأنه كان أيضًا كودًا ميتًا غير مستخدم
    // (المنطق الفعلي موجود في getOrganicMatterIndex أدناه)

    val organicMatterLevels = listOf(
        "أقل من 1% (منخفض)",
        "1.1 - 2% (متوسط)",
        "2.1 - 3% (مرتفع)",
        "أكثر من 3% (عالية جداً)"
    )

    fun getOrganicMatterIndex(percentage: Double): Int {
        // إذا كان أكبر من 3، تحتسب كـ 3 (عالية جداً)
        val adjustedPercentage = if (percentage > 3.0) 3.0 else percentage

        return when {
            adjustedPercentage < 1.0 -> 0
            adjustedPercentage <= 2.0 -> 1
            adjustedPercentage <= 3.0 -> 2
            else -> 3
        }
    }

    val crops = listOf(
        // 1. بقوليات غذائية مروية
        Crop(
            name = "بقوليات غذائية مروية",
            phosphorusRanges = listOf(60.0, 55.0, 45.0, 30.0, 20.0, 0.0),
            nitrogenRanges = listOf(30.0, 25.0, 20.0, 10.0, 0.0, 0.0),
            potassiumRanges = listOf(45.0, 35.0, 25.0, 20.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 2. شوندر سكري خريفي
        Crop(
            name = "شوندر سكري خريفي",
            phosphorusRanges = listOf(120.0, 120.0, 100.0, 70.0, 40.0, 0.0),
            nitrogenRanges = listOf(220.0, 210.0, 200.0, 150.0, 100.0, 0.0),
            potassiumRanges = listOf(160.0, 140.0, 120.0, 100.0, 80.0, 60.0, 30.0, 0.0)
        ),
        // 3. بطاطا خريفية مروية
        Crop(
            name = "بطاطا خريفية مروية",
            phosphorusRanges = listOf(120.0, 130.0, 120.0, 80.0, 40.0, 0.0),
            nitrogenRanges = listOf(195.0, 185.0, 175.0, 100.0, 50.0, 0.0),
            potassiumRanges = listOf(160.0, 150.0, 140.0, 120.0, 90.0, 60.0, 40.0, 0.0)
        ),
        // 4. بقوليات علفية حية
        Crop(
            name = "بقوليات علفية حية",
            phosphorusRanges = listOf(60.0, 55.0, 46.0, 30.0, 20.0, 0.0),
            nitrogenRanges = listOf(30.0, 25.0, 20.0, 10.0, 0.0, 0.0),
            potassiumRanges = listOf(50.0, 45.0, 40.0, 35.0, 30.0, 20.0, 15.0, 0.0)
        ),
        // 5. محاصيل رعوية - تعديل
        Crop(
            name = "محاصيل رعوية",
            phosphorusRanges = listOf(60.0, 55.0, 46.0, 30.0, 20.0, 0.0),
            nitrogenRanges = listOf(30.0, 25.0, 20.0, 10.0, 0.0, 0.0),
            potassiumRanges = listOf(50.0, 45.0, 40.0, 35.0, 30.0, 20.0, 15.0, 0.0)
        ),
        // 6. برسيم مروي - تعديل قيم البوتاسيوم
        Crop(
            name = "برسيم مروي",
            phosphorusRanges = listOf(80.0, 70.0, 60.0, 40.0, 20.0, 0.0),
            nitrogenRanges = listOf(30.0, 25.0, 20.0, 10.0, 0.0, 0.0),
            potassiumRanges = listOf(80.0, 70.0, 60.0, 50.0, 40.0, 30.0, 20.0, 0.0) // ✅ إضافة قيم واقعية
        ),
        // 7. فصة مروية
        Crop(
            name = "فصة مروية",
            phosphorusRanges = listOf(190.0, 190.0, 180.0, 120.0, 80.0, 0.0),
            nitrogenRanges = listOf(30.0, 25.0, 20.0, 10.0, 0.0, 0.0),
            potassiumRanges = listOf(80.0, 70.0, 60.0, 50.0, 40.0, 30.0, 20.0, 0.0) // ✅ إضافة قيم واقعية
        ),
        // 8. ثوم سقي
        Crop(
            name = "ثوم سقي",
            phosphorusRanges = listOf(130.0, 130.0, 110.0, 80.0, 40.0, 0.0),
            nitrogenRanges = listOf(140.0, 130.0, 120.0, 80.0, 40.0, 0.0),
            potassiumRanges = listOf(160.0, 150.0, 140.0, 120.0, 90.0, 60.0, 40.0, 0.0)
        ),
        // 9. ثوم بعل
        Crop(
            name = "ثوم بعل",
            phosphorusRanges = listOf(80.0, 70.0, 60.0, 40.0, 20.0, 0.0),
            nitrogenRanges = listOf(80.0, 70.0, 60.0, 40.0, 0.0, 0.0),
            potassiumRanges = listOf(80.0, 75.0, 70.0, 60.0, 45.0, 30.0, 20.0, 0.0)
        ),
        // 10. خضار شتوية مروية
        Crop(
            name = "خضار شتوية مروية",
            phosphorusRanges = listOf(120.0, 110.0, 100.0, 70.0, 20.0, 0.0),
            nitrogenRanges = listOf(140.0, 130.0, 120.0, 80.0, 60.0, 0.0),
            potassiumRanges = listOf(45.0, 35.0, 30.0, 25.0, 20.0, 0.0, 0.0, 0.0)
        ),
        // 11. خضار شتوية بعل
        Crop(
            name = "خضار شتوية بعل",
            phosphorusRanges = listOf(70.0, 65.0, 50.0, 25.0, 20.0, 0.0),
            nitrogenRanges = listOf(70.0, 60.0, 50.0, 30.0, 0.0, 0.0),
            potassiumRanges = listOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 12. ذرة بيضاء سقي
        Crop(
            name = "ذرة بيضاء سقي",
            phosphorusRanges = listOf(80.0, 70.0, 60.0, 40.0, 25.0, 0.0),
            nitrogenRanges = listOf(100.0, 90.0, 80.0, 40.0, 0.0, 0.0),
            potassiumRanges = listOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 13. بندورة سقي
        Crop(
            name = "بندورة سقي",
            phosphorusRanges = listOf(140.0, 130.0, 120.0, 80.0, 50.0, 0.0),
            nitrogenRanges = listOf(200.0, 190.0, 180.0, 120.0, 80.0, 0.0),
            potassiumRanges = listOf(160.0, 150.0, 140.0, 120.0, 90.0, 60.0, 40.0, 0.0)
        ),
        // 14. بندورة بعل
        Crop(
            name = "بندورة بعل",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 30.0, 0.0),
            nitrogenRanges = listOf(100.0, 90.0, 80.0, 40.0, 0.0, 0.0),
            potassiumRanges = listOf(80.0, 75.0, 70.0, 60.0, 45.0, 30.0, 20.0, 0.0)
        ),
        // 15. بصل سقي
        Crop(
            name = "بصل سقي",
            phosphorusRanges = listOf(140.0, 130.0, 120.0, 80.0, 50.0, 0.0),
            nitrogenRanges = listOf(140.0, 130.0, 120.0, 80.0, 40.0, 0.0),
            potassiumRanges = listOf(160.0, 150.0, 140.0, 120.0, 90.0, 60.0, 40.0, 0.0)
        ),
        // 16. بصل بعل
        Crop(
            name = "بصل بعل",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 30.0, 0.0),
            nitrogenRanges = listOf(100.0, 90.0, 80.0, 50.0, 20.0, 0.0),
            potassiumRanges = listOf(80.0, 75.0, 70.0, 60.0, 45.0, 30.0, 20.0, 0.0)
        ),
        // 17. خضروات مختلفة
        Crop(
            name = "خضروات مختلفة",
            phosphorusRanges = listOf(130.0, 120.0, 100.0, 70.0, 40.0, 0.0),
            nitrogenRanges = listOf(170.0, 160.0, 150.0, 100.0, 50.0, 0.0),
            potassiumRanges = listOf(120.0, 120.0, 100.0, 80.0, 70.0, 60.0, 50.0, 0.0)
        ),
        // 18. بطيخ أحمر وأصفر سقي
        Crop(
            name = "بطيخ أحمر وأصفر سقي",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 30.0, 0.0),
            nitrogenRanges = listOf(140.0, 130.0, 120.0, 80.0, 40.0, 0.0),
            potassiumRanges = listOf(140.0, 120.0, 100.0, 80.0, 60.0, 40.0, 20.0, 0.0)
        ),
        // 19. بطيخ أحمر وأصفر بعل
        Crop(
            name = "بطيخ أحمر وأصفر بعل",
            phosphorusRanges = listOf(70.0, 60.0, 50.0, 40.0, 25.0, 0.0),
            nitrogenRanges = listOf(70.0, 60.0, 50.0, 30.0, 0.0, 0.0),
            potassiumRanges = listOf(70.0, 60.0, 50.0, 40.0, 20.0, 20.0, 10.0, 0.0)
        ),
        // 20. شوندر صيفي
        Crop(
            name = "شوندر صيفي",
            phosphorusRanges = listOf(130.0, 110.0, 100.0, 70.0, 30.0, 0.0),
            nitrogenRanges = listOf(220.0, 210.0, 200.0, 150.0, 100.0, 0.0),
            potassiumRanges = listOf(140.0, 120.0, 100.0, 80.0, 60.0, 40.0, 20.0, 0.0)
        ),
        // 21. بطاطا ربيعية وصيفية
        Crop(
            name = "بطاطا ربيعية وصيفية",
            phosphorusRanges = listOf(140.0, 130.0, 120.0, 80.0, 60.0, 0.0),
            nitrogenRanges = listOf(180.0, 170.0, 156.0, 120.0, 80.0, 0.0),
            potassiumRanges = listOf(160.0, 150.0, 140.0, 120.0, 90.0, 60.0, 40.0, 0.0)
        ),
        // 22. ذرة صفراء سقي
        Crop(
            name = "ذرة صفراء سقي",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 35.0, 0.0),
            nitrogenRanges = listOf(160.0, 150.0, 135.0, 90.0, 40.0, 0.0),
            potassiumRanges = listOf(90.0, 80.0, 70.0, 50.0, 30.0, 20.0, 0.0, 0.0)
        ),
        // 23. ذرة صفراء بعل
        Crop(
            name = "ذرة صفراء بعل",
            phosphorusRanges = listOf(60.0, 50.0, 40.0, 30.0, 20.0, 0.0),
            nitrogenRanges = listOf(80.0, 70.0, 60.0, 30.0, 0.0, 0.0),
            potassiumRanges = listOf(45.0, 40.0, 25.0, 25.0, 15.0, 0.0, 0.0, 0.0)
        ),
        // 24. تبغ
        // ✅ تصحيح: قيمة الفوسفور عند أعلى مستوى PPM أصبحت 0.0 لتتسق مع
        // نفس النمط المعتمد في جميع المحاصيل الأخرى بالقاعدة (لا حاجة لسماد فوسفوري عند PPM مرتفع جداً)
        Crop(
            name = "تبغ",
            phosphorusRanges = listOf(200.0, 190.0, 180.0, 150.0, 100.0, 0.0),
            nitrogenRanges = listOf(250.0, 240.0, 230.0, 180.0, 140.0, 0.0),
            potassiumRanges = listOf(180.0, 170.0, 160.0, 150.0, 120.0, 90.0, 50.0, 0.0)
        ),
        // 25. فول سوداني مروي
        Crop(
            name = "فول سوداني مروي",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 30.0, 0.0),
            nitrogenRanges = listOf(60.0, 50.0, 40.0, 20.0, 0.0, 0.0),
            potassiumRanges = listOf(70.0, 60.0, 50.0, 40.0, 30.0, 20.0, 10.0, 0.0)
        ),
        // 26. عباد شمس زيتي مروي
        Crop(
            name = "عباد شمس زيتي مروي",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 30.0, 0.0),
            nitrogenRanges = listOf(60.0, 50.0, 40.0, 20.0, 0.0, 0.0),
            potassiumRanges = listOf(70.0, 60.0, 50.0, 40.0, 30.0, 20.0, 10.0, 0.0)
        ),
        // 27. عباد شمس زيتي بعل
        Crop(
            name = "عباد شمس زيتي بعل",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 30.0, 0.0),
            nitrogenRanges = listOf(50.0, 40.0, 30.0, 15.0, 0.0, 0.0),
            potassiumRanges = listOf(35.0, 30.0, 25.0, 20.0, 15.0, 10.0, 5.0, 0.0)
        ),
        // 28. سمسم مروي
        Crop(
            name = "سمسم مروي",
            phosphorusRanges = listOf(110.0, 100.0, 80.0, 60.0, 30.0, 0.0),
            nitrogenRanges = listOf(60.0, 50.0, 40.0, 20.0, 0.0, 0.0),
            potassiumRanges = listOf(70.0, 60.0, 50.0, 40.0, 30.0, 20.0, 10.0, 0.0)
        ),
        // 29. سمسم بعل
        Crop(
            name = "سمسم بعل",
            phosphorusRanges = listOf(60.0, 50.0, 40.0, 30.0, 20.0, 0.0),
            nitrogenRanges = listOf(50.0, 40.0, 30.0, 15.0, 0.0, 0.0),
            potassiumRanges = listOf(35.0, 30.0, 25.0, 20.0, 15.0, 10.0, 5.0, 0.0)
        ),
        // 30. قمح عالي الإنتاج مروي
        Crop(
            name = "قمح عالي الإنتاج مروي",
            phosphorusRanges = listOf(100.0, 85.0, 70.0, 50.0, 30.0, 0.0),
            nitrogenRanges = listOf(160.0, 150.0, 138.0, 120.0, 80.0, 0.0),
            potassiumRanges = listOf(160.0, 140.0, 120.0, 100.0, 80.0, 60.0, 40.0, 0.0)
        ),
        // 31. قمح عالي الإنتاج بعل أولى
        Crop(
            name = "قمح عالي الإنتاج بعل أولى",
            phosphorusRanges = listOf(65.0, 55.0, 45.0, 30.0, 15.0, 0.0),
            nitrogenRanges = listOf(110.0, 100.0, 92.0, 50.0, 40.0, 0.0),
            potassiumRanges = listOf(100.0, 80.0, 60.0, 40.0, 30.0, 20.0, 0.0, 0.0)
        ),
        // 32. قمح عالي الإنتاج بعل ثانية
        Crop(
            name = "قمح عالي الإنتاج بعل ثانية",
            phosphorusRanges = listOf(60.0, 50.0, 40.0, 25.0, 15.0, 0.0),
            nitrogenRanges = listOf(80.0, 75.0, 69.0, 40.0, 0.0, 0.0),
            potassiumRanges = listOf(100.0, 80.0, 60.0, 40.0, 30.0, 20.0, 0.0, 0.0)
        ),
        // 33. قمح محلي بعل أولى
        Crop(
            name = "قمح محلي بعل أولى",
            phosphorusRanges = listOf(60.0, 50.0, 40.0, 35.0, 25.0, 0.0),
            nitrogenRanges = listOf(55.0, 50.0, 41.0, 20.0, 0.0, 0.0),
            potassiumRanges = listOf(60.0, 50.0, 35.0, 20.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 34. قمح محلي بعل ثانية
        Crop(
            name = "قمح محلي بعل ثانية",
            phosphorusRanges = listOf(40.0, 35.0, 25.0, 20.0, 15.0, 0.0),
            nitrogenRanges = listOf(40.0, 35.0, 25.0, 15.0, 0.0, 0.0),
            potassiumRanges = listOf(60.0, 50.0, 35.0, 20.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 35. شعير مروي
        Crop(
            name = "شعير مروي",
            phosphorusRanges = listOf(80.0, 70.0, 60.0, 40.0, 20.0, 0.0),
            nitrogenRanges = listOf(100.0, 90.0, 80.0, 40.0, 0.0, 0.0),
            potassiumRanges = listOf(60.0, 50.0, 35.0, 20.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 36. شعير بعل أولى
        Crop(
            name = "شعير بعل أولى",
            phosphorusRanges = listOf(70.0, 60.0, 55.0, 35.0, 25.0, 0.0),
            nitrogenRanges = listOf(80.0, 75.0, 69.0, 40.0, 0.0, 0.0),
            potassiumRanges = listOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 37. شعير بعل ثانية
        Crop(
            name = "شعير بعل ثانية",
            phosphorusRanges = listOf(60.0, 50.0, 40.0, 30.0, 20.0, 0.0),
            nitrogenRanges = listOf(55.0, 50.0, 41.0, 20.0, 0.0, 0.0),
            potassiumRanges = listOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        ),
        // 38. شعير بعل ثالثة
        Crop(
            name = "شعير بعل ثالثة",
            phosphorusRanges = listOf(50.0, 45.0, 37.0, 25.0, 20.0, 0.0),
            nitrogenRanges = listOf(40.0, 35.0, 28.0, 15.0, 0.0, 0.0),
            potassiumRanges = listOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        )
    ).sortedBy { it.name }

    // دوال مساعدة لتحديد النطاق المناسب حسب PPM
    fun getPhosphorusIndex(ppm: Double): Int {
        return when {
            ppm < 3 -> 0
            ppm <= 5 -> 1
            ppm <= 7 -> 2
            ppm <= 9 -> 3
            ppm <= 12 -> 4
            else -> 5
        }
    }

    fun getNitrogenIndex(ppm: Double): Int {
        return when {
            ppm < 5 -> 0
            ppm <= 9 -> 1
            ppm <= 15 -> 2
            ppm <= 19 -> 3
            else -> 4
        }
    }

    fun getPotassiumIndex(ppm: Double): Int {
        return when {
            ppm < 60 -> 0
            ppm <= 120 -> 1
            ppm <= 160 -> 2
            ppm <= 240 -> 3
            ppm <= 250 -> 4
            ppm <= 260 -> 5
            ppm <= 420 -> 6
            else -> 7
        }
    }

    fun getCropByName(name: String): Crop? {
        return crops.find { it.name == name }
    }

    fun getAllCropNames(): List<String> {
        return crops.map { it.name }
    }
}
