package com.ayman.soilfert2026

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        // ربط عناصر الواجهة
        val txtDiagnosis = findViewById<TextView>(R.id.txtDiagnosis)
        val txtNeeds = findViewById<TextView>(R.id.txtNeeds)
        val txtFertilizers = findViewById<TextView>(R.id.txtFertilizers)
        val txtAdvice = findViewById<TextView>(R.id.txtAdvice)

        val btnNewAnalysis = findViewById<Button>(R.id.btnNewAnalysis)
        val btnBackToMain = findViewById<Button>(R.id.btnBackToMain)
        val btnShare = findViewById<Button>(R.id.btnShare)

        // استلام النص الكامل
        val rawResult = intent.getStringExtra("RESULT_TEXT") ?: "لا توجد نتائج"

        // تنظيف النص
        val cleaned = rawResult
            .replace("=====", "")
            .replace("-----", "")
            .replace("_____", "")
            .trim()

        // تقسيم النتائج إلى أقسام
        val diagnosis = extract(cleaned, "###DIAGNOSIS###")
        val needs = extract(cleaned, "###NEEDS###")
        val fertilizers = extract(cleaned, "###FERTILIZERS###")
        val advice = extract(cleaned, "###ADVICE###")

        // استخراج المعلومات الإضافية (مستويات PPM حسب Excel)
        val ppmLevels = extractPPMLevels(cleaned)

        // عرض النتائج داخل البطاقات
        txtDiagnosis.text = buildString {
            append("📊 تشخيص التربة\n\n")
            append(formatDiagnosis(diagnosis))
            if (ppmLevels.isNotEmpty()) {
                append("\n\n📈 مستويات العناصر (حسب المعايير المرجعية):\n")
                append(ppmLevels)
            }
        }

        txtNeeds.text = buildString {
            append("📦 التوصية السمادية\n\n")
            append(needs)
        }

        txtFertilizers.text = buildString {
            append("🌿 الأسمدة المقترحة\n\n")
            append(fertilizers)
        }

        txtAdvice.text = advice.trim()

        // زر تحليل جديد
        btnNewAnalysis.setOnClickListener {
            val intent = Intent(this, SoilAnalysisActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }

        // زر العودة للرئيسية
        btnBackToMain.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }

        // زر مشاركة
        btnShare.setOnClickListener {
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, buildShareText(diagnosis, needs, fertilizers, advice))
                type = "text/plain"
            }
            startActivity(Intent.createChooser(shareIntent, "مشاركة التوصية السمادية"))
        }
    }

    /**
     * تنسيق التشخيص مع دعم جميع المستويات
     */
    private fun formatDiagnosis(text: String): String {
        return text
            .lines()
            .map { line ->
                when {
                    line.contains("🔴") && line.contains("منخفض") -> line.replace("🔴", "🔴") + " ⚠️ يحتاج تسميد"
                    line.contains("🟠") && line.contains("متوسط") -> line.replace("🟠", "🟠") + " ✓ مقبول"
                    line.contains("🟢") && line.contains("جيد") -> line.replace("🟢", "🟢") + " ✓ جيد"
                    line.contains("🟢") && line.contains("مرتفع") -> line.replace("🟢", "🟢") + " ✓ ممتاز"
                    line.contains("منخفض جداً") -> "🔴🔴 $line ⚠️ يحتاج تسميد مكثف"
                    line.contains("مرتفع جداً") -> "🟢🟢 $line ✓ يمكن تقليل التسميد"
                    line.contains("عالي جداً") -> "🟢🟢 $line ✓ يمكن تقليل التسميد"
                    line.contains("ممتاز") -> "🟢🟢 $line ✓ ممتاز"
                    else -> line
                }
            }
            .joinToString("\n")
    }

    /**
     * استخراج مستويات PPM حسب Excel من النص
     */
    private fun extractPPMLevels(text: String): String {
        val startMarker = "📊 مستويات العناصر حسب التحليل:"
        val startIndex = text.indexOf(startMarker)
        if (startIndex == -1) return ""

        val endIndex = text.indexOf("\n\n", startIndex)
        val section = if (endIndex == -1)
            text.substring(startIndex)
        else
            text.substring(startIndex, endIndex)

        return section.trim()
    }

    /**
     * ✅ إعادة صياغة كاملة: بناء نص مشاركة بأسلوب تقرير علمي/فني احترافي
     * خالٍ من أي مصطلحات برمجية أو داخلية، مناسب للمشاركة المباشرة عبر
     * وسائل التواصل الاجتماعي (واتساب، فيسبوك، إلخ)
     */
    private fun buildShareText(diagnosis: String, needs: String, fertilizers: String, advice: String): String {
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale("ar")).format(Date())

        return buildString {
            append("🌾═══════════════════════🌾\n")
            append("      تقرير التوصية السمادية\n")
            append("🌾═══════════════════════🌾\n")
            append("📅 تاريخ التقرير: $dateStr\n")
            append("───────────────────────────\n\n")

            append("📊 تشخيص التربة\n")
            append("───────────────\n")
            append(diagnosis.trim())
            append("\n\n")

            append("📦 التوصية السمادية\n")
            append("───────────────\n")
            append(needs.trim())
            append("\n\n")

            append("🌿 الأسمدة الموصى بها\n")
            append("───────────────\n")
            append(fertilizers.trim())
            append("\n\n")

            append("💡 الإرشادات الفنية\n")
            append("───────────────\n")
            append(advice.trim())
            append("\n\n")

            append("🌾═══════════════════════🌾\n")
            append("   تطبيق التوصية السمادية الذكي\n")
            append("🌾═══════════════════════🌾")
        }
    }

    /**
     * دالة استخراج جزء من النص بين عنوانين
     */
    private fun extract(text: String, key: String): String {
        val startIndex = text.indexOf(key)
        if (startIndex == -1) return ""

        val start = startIndex + key.length
        val endIndex = text.indexOf("###", start)

        return if (endIndex == -1)
            text.substring(start).trim()
        else
            text.substring(start, endIndex).trim()

    }
}
